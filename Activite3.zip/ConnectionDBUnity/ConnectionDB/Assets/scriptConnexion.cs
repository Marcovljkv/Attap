﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class scriptConnexion : MonoBehaviour
{
    public void ConnectionDb()
    {
        InputField nom = GameObject.Find("Nom").GetComponent<InputField>();
        InputField psw = GameObject.Find("Mdp").GetComponent<InputField>();

        WWW www = new WWW("http://127.0.0.1/UnityDbTest/index.php?nom=" + nom.text + "&psw=" + psw.text);
        while (!www.isDone && string.IsNullOrEmpty(www.error))
        {
        }

        if (string.IsNullOrEmpty(www.error));
        else Debug.LogWarning(www.error);

        if (www.text == "Y")
            Debug.Log("Vous vous etes bien logué merci d'avoir utilisé ce programmes");
        else
            Debug.Log("Fail dans le nom ou le mot de passe veuillez ressayer !");
    }
}