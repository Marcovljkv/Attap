<?php

//Initialisation des constantes
define('DB_HOST', "127.0.0.1");
define('DB_NAME', "unitydb");
define('DB_USER', "root");
define('DB_PASS', "");

//  Les requetes
define('GETUSER', "SELECT `psw` FROM `user` WHERE user=:nom");
define('INSERUSER', "INSERT INTO `activite` VALUES (NULL,:nom)");
define('UPDATEUSER', "UPDATE `activite` SET `nomActivite`=:nom WHERE `idActivite`=:id");


function getConnexion() {
    static $dbb = null;

    if ($dbb === null) {
        try {
            $connectionString = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';';
            $dbb = new PDO($connectionString, DB_USER, DB_PASS);
            $dbb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die('Erreur : ' . $e->getMessage());
        }
    }
    return $dbb;
}

function getUser($name) {
    $requete = getConnexion()->prepare(GETUSER);
    $requete->bindParam(':nom', $name, PDO::PARAM_STR);
    $requete->execute();
    $resultat = $requete->fetchAll(PDO::FETCH_ASSOC);
    return $resultat;
}

function insertUser($name,$psw) {
    $requete = getConnexion()->prepare(INSERTUSER);
    $requete->bindParam(':nom', $name, PDO::PARAM_STR);
    $requete->bindParam(':psw', $psw, PDO::PARAM_STR);
    $requete->execute();
}

function updateActivites($id, $nom) {
    $requete = getConnexion()->prepare(UPDATEUSER);
    $requete->bindParam(':nom', $nom, PDO::PARAM_STR);
    $requete->bindParam(':id', $id, PDO::PARAM_INT);
    $requete->execute();
}
function jeteditsalut(){
    echo "salut";
}