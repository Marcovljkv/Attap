<?php
require './fonctionDB.php';

$nom = $_GET['nom'];
$psw = $_GET['psw'];

if(getUser($nom)[0]['psw']== sha1($psw)){
    echo  "Y";
}